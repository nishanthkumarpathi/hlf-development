'use strict';

const blindAuction = require('./lib/blindAuction');

module.exports.BlindAuction = blindAuction;
module.exports.contracts = [blindAuction];