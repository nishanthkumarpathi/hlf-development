'use strict';

const reportsContract = require('./lib/reportsContract');

module.exports.ReportsContract = reportsContract;
module.exports.contracts = [reportsContract];